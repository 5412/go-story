package simplemath

/***********************/
/* 函数定义规则：
/* func 函数名(参数名 参数类型,...) (返回值类型) {函数体}
/***********************/
func Add(a int, b int) int {
    return a + b
}
