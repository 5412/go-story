package mp

import "testing"

func TestPlay1(t *testing.T) {
    Play("123", "MP3")
}
