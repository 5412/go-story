package main
import "fmt"
func main() {
    fmt.Println("hello world,你好世界");
}
    
