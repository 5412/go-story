package mp

import "testing"

func TestMP3Player(t *testing.T) {
    p := new(MP3Player)
    p.Play("12312")
}
